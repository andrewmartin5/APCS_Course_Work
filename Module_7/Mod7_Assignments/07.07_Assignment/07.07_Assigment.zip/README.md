PROJECT TITLE: 07.05_Assignment / ElectionTesterV1.java; ElectionTesterV2.java
                    ElectionTesterV3.java; ElectionTesterV4.java; 
                    ElectionTesterV5.java; ElectionTesterV6.java;
                    ElectionTesterV7.java; ElectionTesterV8.java
PURPOSE OF PROJECT: To Transverse through arrays and arraylists, as well as to
                        replace values within arrays and arraylists
VERSION and DATE: 1.0 - 8.0 3/17/2021
AUTHORS: Andrew Martin

******************************** P M R *********************************************
<+s>: I figured out the delete function rather easily
      
<-s>: I kept missing for each loops to change into for loops because my methods were
        in a bad order
************************************************************************************
In the future: I will order my methods while I program so I don't have to fix them
                later