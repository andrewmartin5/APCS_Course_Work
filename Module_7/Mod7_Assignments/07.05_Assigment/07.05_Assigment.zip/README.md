PROJECT TITLE: 07.05_Assignment / ElectionTesterV1.java; ElectionTesterV2.java
                    ElectionTesterV3.java; ElectionTesterV4.java
PURPOSE OF PROJECT: To Transverse through arrays and arraylists, as well as to
                        replace values within arrays and arraylists
VERSION and DATE: 1.0 - 4.0 3/15/2021
AUTHORS: Andrew Martin

******************************** P M R *********************************************
<+s>: I got all of the funcitonality working rather easily
      
<-s>: I had a bit of trouble formatting user output
************************************************************************************
In the future: I will make sure to get my output formatted before creating more.