PROJECT TITLE: 05.08_Assignment / GuitarV3.java; test.java
PURPOSE OF PROJECT: To create a guitar object with both a name and a tuning and to
                        be able to change the tuning and to play a note while using
                        two different files
VERSION and DATE: 1.0 2/8/2021
AUTHORS: Andrew Martin

******************************** P M R *********************************************
<+s>: I reformatted my code and allowed it to be used with multiple objects rather 
        easily
      
<-s>: I wrote my methods in GuitarV8.java in a very odd order, which made it 
        difficult to read. To fix this, I just had to reorder said methods.
************************************************************************************
In the future: I will order my methods while I am writing my program so as to not
                confuse myself.