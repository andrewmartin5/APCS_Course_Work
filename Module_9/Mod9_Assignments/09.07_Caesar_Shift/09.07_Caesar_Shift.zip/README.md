PROJECT TITLE: 09.07_Caesar_Shift; Encryption.java / Decryption.java / 
                        CaesarTester.java
PURPOSE OF PROJECT: To create a program that can be used to encrypt and decrypt 
                        messages using the Caesar shift method
VERSION and DATE: 1.0 4/13/2021
AUTHORS: Andrew Martin

******************************** P M R *********************************************
<+s>: The user input setup went very smoothly
      
<-s>: I struggled with the encoding and decoding. I forgot how to separate strings
        so I needed to use some methods I was unfamiliar with.
************************************************************************************
In the future: I will make sure I know how to use a method before I use it