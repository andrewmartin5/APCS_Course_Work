PROJECT TITLE: 09.02_Assignment; Forest.java / GameTerrainTester.java / 
                Mountain.java / River.java / Terrain.java / Water.java / 
                WinterMountain.java
PURPOSE OF PROJECT: To Create a terrain class heirarchy
VERSION and DATE: 1.0 4/10/2021
AUTHORS: Andrew Martin

******************************** P M R *********************************************
<+s>: I figured out managing the class heirarchy rather easily
      
<-s>: I struggled to get the descriptions to work together, as I kept using higher
        level private variables instead of their accessor methods.
************************************************************************************
In the future: I will use accessor methods to retrieve information that is not in 
                    the current class