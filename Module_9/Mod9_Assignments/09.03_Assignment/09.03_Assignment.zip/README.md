PROJECT TITLE: 09.03_Assignment; Circle2.java / Cylinder2.java / Oval2.java / 
                        OvalCylinder2.java / CircleTester.java
PURPOSE OF PROJECT: To create multiple classes with similar characteristics to 
                        circles
VERSION and DATE: 1.0 4/11/2021
AUTHORS: Andrew Martin

******************************** P M R *********************************************
<+s>: I got the polymorphism working properly first try
      
<-s>: I forgot to make an ArrayList until after I wrote the rest of the program
************************************************************************************
In the future: I will make sure to implement all my features in an order that makes 
                        sense.