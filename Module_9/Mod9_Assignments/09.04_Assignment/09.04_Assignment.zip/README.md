PROJECT TITLE: 09.04_Assignment; Box4.java / Cube4.java / Parallelogram4.java / 
                    Rectangle4.java / Square.java / ShapeTester.java
PURPOSE OF PROJECT: To create multiple classes with similar characteristics to 
                        rectangles and override Object methods within these classes
VERSION and DATE: 1.0 4/11/2021
AUTHORS: Andrew Martin

******************************** P M R *********************************************
<+s>: I figured out the toString methods rather easily
      
<-s>: I forgot to cast my object when I was implementing the equals() override, 
        resulting in errors.
************************************************************************************
In the future: When I need to change an object's type, I will cast it.